package com.alderetesmaria.zoo2;

import com.alderetesmaria.zoo2.bat.Bat;

public class BatTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bat bat1 = new Bat();
		
		System.out.println(bat1.attackTown());
		System.out.println(bat1.attackTown());
		System.out.println(bat1.attackTown());
		System.out.println(bat1.eatHumans());
		System.out.println(bat1.eatHumans());
		System.out.println(bat1.fly());
		System.out.println(bat1.fly());
		System.out.println(bat1.desiplayEnergy());
	}

}
