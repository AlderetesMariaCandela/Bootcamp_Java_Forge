package como.alderetesmaria.maestro;

public class Samurai extends Human {

}
