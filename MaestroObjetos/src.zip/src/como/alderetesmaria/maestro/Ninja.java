package como.alderetesmaria.maestro;

public class Ninja extends Human {

}
