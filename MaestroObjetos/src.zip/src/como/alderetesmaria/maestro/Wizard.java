package como.alderetesmaria.maestro;

public class Wizard extends Human{

}
