package com.alderetesmaria.calculadora.interfaces;

public interface Operacion {
	
	void performOperation();

}
