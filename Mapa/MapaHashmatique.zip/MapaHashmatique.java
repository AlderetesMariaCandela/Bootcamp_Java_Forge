import java.util.HashMap;


public class MapaHashmatique{

    public  HashMap<String, String> trackList(){

        HashMap<String, String> listaHash = new HashMap<String, String>();
        //agrego
        listaHash.put("Dreams", "Oh, my life is changing everyday...");
        listaHash.put("I Will Always", "I Will Always... ");
        listaHash.put("Linger", "If you, if you could return...");
        listaHash.put("Put Me Down", "Let me take you by the hand...");

        return listaHash;

    }


}

