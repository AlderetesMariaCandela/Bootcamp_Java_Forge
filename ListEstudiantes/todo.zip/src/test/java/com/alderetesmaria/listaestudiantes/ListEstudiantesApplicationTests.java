package com.alderetesmaria.listaestudiantes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ListEstudiantesApplicationTests {

	@Test
	void contextLoads() {
	}

}
