package com.alderetesmaria.listaestudiantes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ListEstudiantesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ListEstudiantesApplication.class, args);
	}

}
