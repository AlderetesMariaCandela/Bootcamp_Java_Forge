public class PitagorasTest {
    public static void main (String[] args){
        Pitagoras hipotenusa = new Pitagoras();
        double result = hipotenusa.calcularHipotenusa(3,5);
        System.out.println("La hipotenusa es "+ result);
    }
}