package com.alderetesmaria.mostrarfecha;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MostrarFechaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MostrarFechaApplication.class, args);
	}

}
