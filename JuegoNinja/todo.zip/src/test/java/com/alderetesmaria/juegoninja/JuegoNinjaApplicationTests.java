package com.alderetesmaria.juegoninja;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JuegoNinjaApplicationTests {

	@Test
	void contextLoads() {
	}

}
